# src/api/routes_chat.py
import logging
from datetime import datetime
from fastapi import APIRouter, Query, Depends, HTTPException
from bson import ObjectId
from bson.errors import InvalidId
from motor.motor_asyncio import AsyncIOMotorClient
from src.auth.dependencies import get_current_user
from src.agent.react_idea_agent import build_react_chat_agent
from src.core.db import collection, MONGO_URI

router = APIRouter(prefix="/chat", tags=["Chat with Idea Agent"])
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

def safe_float(value, default=0.0):
    try:
        return float(value)
    except (ValueError, TypeError):
        return default

@router.post("/idea/{id}")
async def chat_with_idea(
    id: str,
    message: str = Query(..., description="User message to the idea agent"),
    current_user: dict = Depends(get_current_user),
):
    # === DEBUG: inspect the incoming path-param ===
    logger.debug("🔍 Entered chat_with_idea, raw id param = %r (type %s)", id, type(id))

    user_id = current_user["sub"]
    logger.debug("➡️  current_user.sub = %s", user_id)

    # 1) Validate the ID
    try:
        oid = ObjectId(id)
    except InvalidId:
        logger.error("❌ Invalid ObjectId format for id=%r", id)
        raise HTTPException(status_code=400, detail="Invalid idea ID format")

    # 2) Load the idea doc
    idea_doc = await collection.find_one({"_id": oid, "user_id": user_id})
    logger.debug("📄 idea_doc fetched = %r", idea_doc)
    if not idea_doc:
        logger.warning("⚠️  No idea found for _id=%s user=%s", id, user_id)
        raise HTTPException(status_code=404, detail="Idea not found")

    # 3) Extract
    description = idea_doc.get("description", "")
    roi         = safe_float(idea_doc.get("roi"), 0.0)
    effort      = safe_float(idea_doc.get("effort"), 1.0)
    logger.debug("📋 description=%r, roi=%s, effort=%s", description, roi, effort)

    # 4) Build & invoke agent
    agent = build_react_chat_agent(
        idea_id=id,
        idea_description=description,
        roi=roi,
        effort=effort,
        user_id=user_id,
        mongo_uri=MONGO_URI,
    )
    reply = agent.invoke({"input": message})
    logger.debug("🤖 Agent reply = %r", reply)

    # 5) Update the last_updated timestamp
    await collection.update_one(
        {"_id": oid, "user_id": user_id},
        {"$set": {"last_updated": datetime.utcnow()}}
    )
    logger.debug("⏱  Updated last_updated on idea %s", id)

    # 6) Fetch raw memory documents
    session_id = f"{user_id}_{id}"
    logger.debug("🔗 Using session_id = %r", session_id)

    client = AsyncIOMotorClient(MONGO_URI)
    memcol = client["thinkwise_chat"]["memory"]

    raw_docs = await memcol.find(
        {"session_id": session_id}
    ).sort("timestamp", 1).to_list(length=1000)
    logger.debug("📚 raw memory docs (first 5) = %r", raw_docs[:5])

    # 7) Format for return
    chat_history = []
    for rec in raw_docs:
        # we expect rec to be a dict with keys "type","data","timestamp", etc.
        logger.debug("    record type=%s data=%s ts=%s", rec.get("type"), rec.get("data"), rec.get("timestamp"))
        chat_history.append({
            "from":      rec.get("type"),
            "text":      rec.get("data", {}).get("text"),
            "timestamp": rec.get("timestamp").isoformat() if rec.get("timestamp") else None
        })

    return {
        "idea_id":      id,
        "reply":        reply,
        "chat_history": chat_history,
    }